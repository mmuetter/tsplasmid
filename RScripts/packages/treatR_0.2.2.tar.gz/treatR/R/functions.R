################################################################################
# functions for creating new plate files                                       #
################################################################################

#' Generate turnover tibble
#'
#' generates a tibble of length n_rwells with wells to be replaced
#' from source
#'
#' @param pars the list of experiment parameters
#' @param transfer used to override default turnover for setup
#' @param forceTurnover vector of rwells to force turnover
#' @family plate_creation
#' @export
gen_turnover <- function(
  pars,
  transfer,
  forceTurnover = NULL) {
  
  if (transfer == 0) {
    turnover <- sample(rep(pars$community$strain, pars$community$n), pars$format$n_patients)
  } else {
    turnover <- as.character(rep(NA, pars$format$n_patients))
    turnover_rate  <- pars$rates$turnover
    which_turnover <- runif(pars$format$n_patients) < turnover_rate
    if (!is.null(forceTurnover)) {
      which_turnover[which(pars$format$rwells_p[[1]] == forceTurnover)] <- TRUE
    }
    n_turnover <- sum(which_turnover)
    turnover[which_turnover] <- sample(pars$community$strain,
        size = n_turnover,
        prob = pars$community$n / pars$format$n_patients,
        replace = TRUE)
  }

  out <- as.character(rep(NA, pars$format$n_rwells))
  out[pars$format$rwells_p[[1]]] <- turnover
  out[pars$format$rwells_bl[[1]]] <- "bl"

  return(tibble(
    rwell = 1:pars$format$n_rwells,
    turnover_strain = out))
}

#' Generate infection vector
#'
#' generates a vector of length n_rwells with destination wells for each well
#' that infects
#'
#' @param pars the list of experiment parameters
#' @param transfer transfer number
#' @param ignoreRWell rwells to ignore for infection
#' @family plate_creation
#' @export
gen_infection <- function(
  pars,
  transfer,
  ignoreRWell) {

  out <- tibble(
    rwell = 1:pars$format$n_rwells,
    infection_to_well = as.integer(rep(NA, pars$format$n_rwells)))

  if (transfer != 0) {
    wells_choose <- runif(pars$format$n_patients) < pars$rates$infection
    wells_that_infect <- setdiff(
      pars$format$rwells_p[[1]][wells_choose],
      ignoreRWell # don't use these wells for infections
    )

    n_infection <- length(wells_that_infect)
    wells_to_infect <- sample(
      setdiff(pars$format$rwells_p[[1]], wells_that_infect),
      size = n_infection, replace = TRUE)
    out$infection_to_well[out$rwell %in% wells_that_infect] <- wells_to_infect
  }
  return(out)
}

#' Generate treatment vector
#'
#' generates a vector of length n_rwells with treatments for the wells
#'
#' @param pars the list of experiment parameters
#' @param transfer transfer number
#' @param condition which condition?
#' @family plate_creation
#' @export
gen_treatment <- function(
  pars,
  transfer,
  condition) {
  if (transfer == 0) {
    out <- rep("none", pars$format$n_rwells)
  } else {
    out <- character(pars$format$n_rwells)
    this_condition <- filter(pars$treatments, plate == condition)
    if (this_condition$period != 1) {
      which_drug <- rep(1:length(this_condition$drugs[[1]]),
        each = 2, length.out = transfer)[transfer]
    } else {
      which_drug <- seq(transfer %% this_condition$period + 1,
      length.out = length(this_condition$probability[[1]]))
    }
    #treatment
    out[pars$format$rwells_p[[1]]] <- sample(
      this_condition$drugs[[1]][which_drug],
      size = pars$format$n_patients,
      prob = this_condition$probability[[1]],
      replace = TRUE)
    #blanks
    out[pars$format$rwells_bl[[1]]] <- "none"
  }
  return(tibble(
    rwell = 1:pars$format$n_rwells,
    treatment_with = out))
}

#' Generate barcode files for EvoWare
#'
#' Generates barcode files that evoware can read. creates a txt files with
#' barcodes only and a .csv with more info
#'
#' @param barcodes data.frame of barcodes
#' @param path where to save the files (no / at end)
#' @param filename filename without extension
#' @param transfer_n transfer number
#' @param run_n run number
#' @param n plate number
#' @param description description (assay, on, agar)
#' @family general
#' @export
gen_barcodefile <- function(
  barcodes,
  path,
  filename,
  transfer_n,
  run_n,
  n,
  description) {

  if (run_n == "max") {
    runs <- filter(barcodes,
      transfer == transfer_n,
      desc == description)
    run_n  <- max(runs$run)
  }

  if (description == "assay") {
    output <- filter(barcodes,
      transfer == transfer_n,
      run == run_n,
      desc == description)
  } else {
    output <- filter(barcodes,
      transfer == transfer_n,
      run == run_n,
      desc == description,
      plate_n == n)
  }

  # put in a reasonable order
  new_order <- c(
    which(output$ab == "N"),
    which(output$ab == "A"),
    which(output$ab == "B"),
    which(output$ab == "AB")
    )
  output <- output[new_order, ]

  #save
  output_path <- stringr::str_c(path, "/", filename)

  write_delim(output["barcode"], path = str_c(output_path, ".txt"),
    col_names = FALSE)

  readr::write_csv(output, path = stringr::str_c(output_path, "_info.csv"))

  ### LOG OUTPUT
  cat("generated BC file:", filename, "\n")
}

#' combine auto and manual
#'
#' function description
#'
#' @param auto logical vector of automatic classification
#' @param manual logical vector of manual classification
#' @family analysis
#' @export
growthcombine <- function(auto, manual){
  out <- auto
  out[!is.na(manual)] <- manual[!is.na(manual)]
  return(out)
}

#' growth in drugs to integer
#'
#' given growth in 4 conditions returns the integer of the corresponding
#' binary value. e.g. TRUE,FALSE,TRUE,TRUE => 1011 => 13
#'
#' @param N growth in N? (vector of logical)
#' @param A growth in A? (vector of logical)
#' @param B growth in B? (vector of logical)
#' @param AB growth in AB? (vector of logical)
#' @section Output:
#'    vector of integers
#' @family hospital_experiment
#' @export
growthToPhenotype <- function(N, A, B, AB) {
  out  <- N + 2 * A + 4 * B + 8 * AB
  return(out)
}

#' Determine mix phenotype
#'
#' expected phenotype with no competition and no selection/treatment
#'
#' @param turnover_phenotype turnover phenotype
#' @param transfer_phenotype transfered phenotype
#' @param infection_phenotype infection phenotype
#' @family hospital_experiment
#' @export
mixPhenotype <- function(
  turnover_phenotype,
  transfer_phenotype,
  infection_phenotype){
  turnover_phenotype[is.na(turnover_phenotype)] <- 0
  transfer_phenotype[is.na(transfer_phenotype)] <- 0
  infection_phenotype[is.na(infection_phenotype)] <- 0

  out_1  <- bitwOr(turnover_phenotype, transfer_phenotype)
  out <- bitwOr(out_1, infection_phenotype)
  return(out)
}

#' Decode  phenotype
#'
#' human readable version of phenotype
#'
#' @param p phenotype integer
#' @family hospital_experiment
#' @export
decodePhenotype <- function(p) {
  pBin <- intToBin(p, l = 8)
  pBinVector <- rev(str_split(pBin, pattern = "")[[1]])
  names(pBinVector) <- c("agarN", "agarA", "agarB", "agarAB", "growth", "lowA", "lowB", "lowAB")

  return(pBinVector)
}
