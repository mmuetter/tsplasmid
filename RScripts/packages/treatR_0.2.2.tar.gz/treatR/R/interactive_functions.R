#' StoreX Panel
#' 
#' runs 
#'
#' @param data_dir path to data directory
#' @param storex_file path to storex pos list
#' @param plates_file path to barcode file
#' @param options.list list of options for shiny
#' @family interactive functions
#' @export
storeX_panel <- function(
  data_dir = "/Users/Daniel/polybox/Shared/Robot-Shared/TreatmentStrategies",
  storex_file = str_c(data_dir,
    "/RScripts/StoreX_PosListExample.txt"),
  plates_file = str_c(data_dir,
    "/experiments/20161202_output/barcodes.csv"),
  option.list = list(
    shiny.launch.browser = TRUE,
    encoding = "UTF-8")
  ){
  library(shiny)
  library(tidyverse)
  library(stringr)
  library(rhandsontable)

  shinyApp(
    onStart = function(options = option.list){
      options(options)
    },
    ui = shinyUI(
      fluidPage(title = "storeX Panel",
        tags$head(
          tags$style(type = "text/css",
            "label.radio { display: inline-block; }",
            ".radio input[type=\"radio\"] { float: none; }"),
          tags$style(type = "text/css",
            "select { max-width: 200px; }"),
          tags$style(type = "text/css",
            "textarea { max-width: 185px; }"),
          tags$style(type = "text/css",
            ".jslider { max-width: 200px; }"),
          tags$style(type = "text/css",
            ".well { max-width: 310px; }"),
          tags$style(type = "text/css",
            ".span4 { max-width: 310px; }"),
          tags$style(type = "text/css",
            ".control-label { font-weight: normal; }"),
          tags$style(type = "text/css",
            ".selectize-input { font-family: monospace, monospace; }"),
          tags$style(type = "text/css",
            "body {background-color: #cacaca; font-family: monospace, monospace;}"),
          tags$style(type = "text/css",
            "label { font-weight: normal; }"),
          tags$style(type = "text/css",
            "#logoC {font-size: 50%;}"),
          tags$style(type = "text/css",
            ".tab-content {background-color: #FFFFFF;}")),
        fluidRow(id = "titleBar",
          column(10, id = "logoC",
            HTML("<XMP>
███████╗████████╗ ██████╗ ██████╗ ███████╗██╗  ██╗    ██████╗  █████╗ ███╗   ██╗███████╗██╗     
██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗██╔════╝╚██╗██╔╝    ██╔══██╗██╔══██╗████╗  ██║██╔════╝██║     
███████╗   ██║   ██║   ██║██████╔╝█████╗   ╚███╔╝     ██████╔╝███████║██╔██╗ ██║█████╗  ██║     
╚════██║   ██║   ██║   ██║██╔══██╗██╔══╝   ██╔██╗     ██╔═══╝ ██╔══██║██║╚██╗██║██╔══╝  ██║     
███████║   ██║   ╚██████╔╝██║  ██║███████╗██╔╝ ██╗    ██║     ██║  ██║██║ ╚████║███████╗███████╗
╚══════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝                                                                                          
storeX Control Panel                                                                   /dca 2016
</XMP>")),
          column(2,
            tags$br(),
            selectizeInput(
              "exp", "Experiment", choices = NA, multiple = FALSE,
              selected = NA
            )
          )
        ), # fluidRow
        fluidRow(
          column(12,
            tabsetPanel(
              tabPanel("storeX",
                rHandsontableOutput("storeX_hot")
              ),
              tabPanel("plates",
                rHandsontableOutput("plates_hot")
              )
            )
          )
        )
      ) # fluidPage
    ), # shinyUI
    server = function(input, output, session){
      observe({
        #update experiment selection
        updateSelectizeInput(session, "exp",
          choices = basename(experiments()$output_directory),
          selected = basename(experiments()$output_directory)[1])
      })

      experiments <- reactive({
        experiments <- read_csv(
          file = str_c(data_dir, "/experiments/experiments.csv"),
          col_types = cols(
          id = col_integer(),
          created = col_datetime(format = ""),
          output_directory = col_character(),
          exp_name = col_character()))
        return(experiments)
      })

      plates <- reactive({
        plates <- read_csv(plates_file,
          col_types = cols(
            transfer = col_integer(),
            run = col_integer(),
            desc = col_character(),
            plate_n = col_integer(),
            barcode = col_character(),
            ab = col_character()))
        return(plates)
      })

      storex_data <- reactive({
        storex <- rrobot::read_storex(storex_file)
        return(storex)
      })

      output$storeX_hot <- renderRHandsontable({
        if (!is.null(input$hot)) {
          storeX_hot <- hot_to_r(input$hot)
        } else {
          storeX_hot <- storex_data() %>%
            left_join(plates(), by = "barcode")
        }

        rhandsontable(storeX_hot) %>%
          hot_table(highlightCol = TRUE, highlightRow = TRUE) %>%
          hot_col(col = c("carrier", "cartridge", "position", "barcode"),
            readOnly = TRUE) %>%
          hot_col(col = "ab", type = "dropdown",
            source = c("N", "A", "B", "AB"), strict = TRUE) %>%
          hot_col(col = "desc", type = "dropdown",
            source = c("assay", "agar", "on"), strict = TRUE) %>%
          hot_rows(fixedRowsTop = 1)
      })
    }
  )
}