#' Plot transfers
#'
#' @param phenotype_data phenotype data
#' @param whichPlate which plate to plot
#' @param d_reps distance of replicates
#' @param pars parameter
#' @param phenotype_table phenotyp lookup table
#' @section Output:
#'    plot of all wells over all transfers
#' @family hospital_experiment
#' @export
transfersPlot <- function(phenotype_data, whichPlate, d_reps = 0.1, pars,
  phenotype_table){
  plot_data <- filter(phenotype_data, plate == whichPlate)
  plot_data$transfer_x <- 0
  for (i in 1:max(plot_data$rep)){
    plot_data[plot_data$rep == i, ]$transfer_x <-
      plot_data[plot_data$rep == i, ]$transfer_n - 1.5 * d_reps +
      (i - 1) * d_reps
  }

  par(oma = c(0, 0, 0, 0), mar = c(2, 2, 2, 2))

  x_min <- 0 - 4 * d_reps - 1
  x_max <- max(plot_data$transfer_n) + 4 * d_reps

  plotTitle <- str_c(
    "Plate ", whichPlate, ", ",
    "Treatment: ", pars$treatments[whichPlate, ]$conditions_name
    )

  plot(1, xlim = c(x_min, x_max), ylim = c(0, 96),
    type = "n", xlab = "", ylab = "", axes = FALSE,
    main = plotTitle)
  axis(side = 1, at = 0:max(plot_data$transfer_n))
  legend_y <- 96 - 0:15 * 2
  legend2_y <- 96 - 17:26 * 2

  points(
    x = rep(x_min, 16),
    y = legend_y,
    pch = 19,
    col = phenotype_table$phenotypes$color)
  text(
    x = rep(x_min, 16),
    y = legend_y,
    cex = 0.8,
    labels = str_c(phenotype_table$phenotypes$int, ": ",
      phenotype_table$phenotypes$let),
    pos = 4)
  text(
    x = rep(x_min, 10) - 0.1,
    y = legend2_y,
    pos = 4,
    cex = 0.8,
    labels = str_c(phenotype_table$changes_legend$class_short, ": ",
      phenotype_table$changes_legend$class_long))

  points(
    x = plot_data$transfer_x,
    y = plot_data$rwell,
    col = plot_data$color, pch = 15, cex = 1)
  points(
    x = plot_data$transfer_x + d_reps / 2,
    y = plot_data$rwell,
    col = "black", pch = plot_data$class_short, cex = 0.5)

  # transfer arrows
  plot_data_transfer <- filter(plot_data, !is.na(transfer_to_well))
    arrows(
      x0 = plot_data_transfer$transfer_n - 1 + 2.5 * d_reps,
      y0 = plot_data_transfer$rwell,
      x1 = plot_data_transfer$transfer_n - 2 * d_reps,
      y1 = plot_data_transfer$transfer_to_well,
      length = 0, lty = 2, col = "gray")
  # infection arrows
  plot_data_infection <- filter(plot_data, !is.na(infection_to_well))
   arrows(
    x0 = plot_data_infection$transfer_n - 1 + 2.5 * d_reps,
    y0 = plot_data_infection$rwell,
    x1 = plot_data_infection$transfer_n - 2 * d_reps,
    y1 = plot_data_infection$infection_to_well,
    length = 0.05, lty = 1, col = "red")

  #replacement
  plot_data_replacement <- filter(plot_data, !is.na(turnover_strain))
  arrows(
    x0 = plot_data_replacement$transfer_n - 3 * d_reps,
    y0 = plot_data_replacement$rwell,
    x1 = plot_data_replacement$transfer_n - 2 * d_reps,
    y1 = plot_data_replacement$rwell,
    length = 0.05)
  text(
    x = plot_data_replacement$transfer_n - 3 * d_reps,
    y = plot_data_replacement$rwell,
    labels = plot_data_replacement$turnover_strain,
    pos = 2,
    cex = 0.6)

  plot_data_treatment <- filter(plot_data, transfer_n > 0)
  rect(xleft = plot_data_treatment$transfer_n - 0.5 - 0.05,
    ybottom = 0,
    xright = plot_data_treatment$transfer_n - 0.5 + 0.05,
    ytop = 97,
    col = "white",
    border = NA)
  text(
    x = plot_data_treatment$transfer_n - 0.5,
    y = plot_data_treatment$rwell,
    labels = plot_data_treatment$treatment_with, cex = 0.6)
}

#' plots a 4x4 representation of a well across all 4 replicates
#' 
#' no description
#' 
#' @param x x coordinate
#' @param y y coordinate
#' @param size of square
#' @param well_df subset data.frame form plates of the well
#' @param gap gap between replicate squares
#' @param pheno_colors data.frame with phenotypes and colors (=var$pheno.table)
#' @param cex cex used for text
#' @param label should the well number be printed above the square?
#' @section Output:
#'    an integer
#' @family hospital_experiment
#' @export
plot_1well <- function(x, y, size, well_df,
  gap = 0,
  cex = 1,
  label = TRUE){
  repwell <- arrange(well_df, rep)
  halfgap <- (gap * size) / 2
  halfsize <- size / 2
  squaresize <- halfsize - halfgap
  rect_args <- list(
    xleft = rep(c(x - halfsize, x + halfgap), 2),
    xright = rep(c(x - halfgap, x + halfsize), 2),
    ytop = rep(c(y + halfsize, y - halfgap), each = 2),
    ybottom = rep(c(y + halfgap, y - halfsize), each = 2),
    col = repwell$color
    )
  do.call(rect, rect_args)
  text(
    x = rect_args$xleft + squaresize / 2,
    y = rect_args$ytop - squaresize / 2,
    labels = repwell$class_short,
    cex = cex)
  if (label){
    text(
    x = x,
    y = y + halfsize,
    labels = repwell$rwell,
    pos = 3, cex = cex
    )
  }
}