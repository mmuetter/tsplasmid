collection of functions for treatment strategies experiment
