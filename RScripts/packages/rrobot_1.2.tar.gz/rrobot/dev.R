library(devtools)

# use_data(basic)

document()
packagePath <- build()
install.packages(packagePath)

polyboxPath <- "/Users/daniel/polybox/Robot-Shared/TSPlasmids/RScripts/packages/"
file.copy(
  from = packagePath,
  to = stringr::str_c(polyboxPath, basename(packagePath)),
  overwrite = TRUE)

rsimPath <- "/Users/daniel/polybox/work/projects/TreatmentStrategiesModel/rpackages/"
file.copy(
  from = packagePath,
  to = stringr::str_c(rsimPath, basename(packagePath)),
  overwrite = TRUE)
