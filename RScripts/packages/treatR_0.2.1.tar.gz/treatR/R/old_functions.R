################################################################################
# old old old                                                                  #
################################################################################

################################################################################
# ANALYSIS FUNCTIONS                                                           #
################################################################################

#' update phenotypes & expectations
#'
#'
#' @param plates the master plate file (a list of lists)
#' @param od_growth_df data.frame of od values
#' @param pickolo_growth_df data.frame of growth phenotypes
#' @param OD_threshold what is growth?
#' @param redo should all plates be redone?
#' @section Output:
#'    plot
#' @family hospital_experiment
#' @export
updatePhenotypes <- function(
  plates,
  od_growth_df,
  pickolo_growth_df,
  exp_vars,
  OD_threshold = 0.01,
  redo = FALSE){

  for (iPlate in seq_along(plates)){
    for (iTransfer in 1:(exp_vars$current_transfer + 1)){
      if (!is.null(attributes(plates[[iPlate]][[iTransfer]])$analyzed) & !redo){
        next
      }
      od_phenotype <- subset(od_growth_df,
        plate == iPlate & transfer == iTransfer - 1)
      pickolo_phenotype <- subset(pickolo_growth_df,
        plate == iPlate & transfer == iTransfer - 1)

      #calculate observed phenotype - pickolo
      if (dim(pickolo_phenotype)[1] != 0){
        plates[[iPlate]][[iTransfer]]$gr_A <-
          growthInAB(pickolo_phenotype, "A")
        plates[[iPlate]][[iTransfer]]$gr_B <-
          growthInAB(pickolo_phenotype, "B")
        plates[[iPlate]][[iTransfer]]$gr_AB <-
          growthInAB(pickolo_phenotype, "AB")
        plates[[iPlate]][[iTransfer]]$gr_N <-
          growthInAB(pickolo_phenotype, "N")
        plates[[iPlate]][[iTransfer]] <- plyr::ddply(plates[[iPlate]][[iTransfer]],
          plyr::.(well), mutate,
          obs_phenotype = growthToPhe_int(gr_N, gr_A, gr_B, gr_AB))
        plates[[iPlate]][[iTransfer]]$obs_phenotype_letters <-
          exp_vars$pheno.table$let[match(
            plates[[iPlate]][[iTransfer]]$obs_phenotype,
            exp_vars$pheno.table$int)]
        plates[[iPlate]][[iTransfer]]$obs_phenotype_bin <-
          exp_vars$pheno.table$bin[match(
            plates[[iPlate]][[iTransfer]]$obs_phenotype,
            exp_vars$pheno.table$int)]
      }

      #calculate observed phenotype - OD
      plates[[iPlate]][[iTransfer]]$ODc <- od_phenotype[match(
        plates[[iPlate]][[iTransfer]]$well, od_phenotype$well), ]$ODc
      plates[[iPlate]][[iTransfer]]$od_phenotype <-
        plates[[iPlate]][[iTransfer]]$ODc > OD_threshold

      #calculate expected phenotypes
      df <- plates[[iPlate]][[iTransfer]]
      cat(paste0("updating p ", iPlate, ", t ", iTransfer - 1, "...\n"))
      for (iWell in df$well){
        istrain <- as.character(df[df$well == iWell, ]$strain)
        if (istrain == "bl"){
          exp_pheno <- 0
        } else if (istrain %in% levels(exp_vars$community$strain)){
          exp_pheno <-
            exp_vars$community$pheno_ind[exp_vars$community$strain == istrain]
        } else {
          last_transfer <- iTransfer - 1
          this_well <- plates[[iPlate]][[last_transfer]][iWell, ]
          last_well <- plates[[iPlate]][[last_transfer]][as.integer(istrain), ]
          last_pheno <- last_well$obs_phenotype
          this_pheno <- this_well$obs_phenotype
          if (is.na(last_pheno)){
            last_pheno <- last_well$exp_phenotype
          }
          if (is.na(this_pheno)){
            this_pheno <- this_well$exp_phenotype
          }
          exp_pheno <- bitwOr(last_pheno, this_pheno)
        }
        plates[[iPlate]][[iTransfer]]$exp_phenotype[iWell] <- exp_pheno

      }
      plates[[iPlate]][[iTransfer]]$exp_phenotype_letters <-
      exp_vars$pheno.table$let[match(
        plates[[iPlate]][[iTransfer]]$exp_phenotype,
        exp_vars$pheno.table$int)]
      #classification
      plates[[iPlate]][[iTransfer]] <- group_by(
        plates[[iPlate]][[iTransfer]], well) %>%
        mutate(colony_class = phenoChangeClassColony(obs_phenotype_letters,
          exp_phenotype_letters, treatment,
          changeMat = exp_vars$pheno.change.agar.matrix))
      plates[[iPlate]][[iTransfer]] <- group_by(
        plates[[iPlate]][[iTransfer]], well) %>%
        mutate(od_class = phenoChangeClassOD(ODc, OD_threshold,
          exp_phenotype_letters, treatment,
          changeMat = exp_vars$pheno.change.OD.matrix))
      #only set flag if pickolo data was present
      if (dim(pickolo_phenotype)[1] != 0){
        attributes(plates[[iPlate]][[iTransfer]])$analyzed <- Sys.time()
      }
      attributes(plates[[iPlate]][[iTransfer]])$OD_threshold <- OD_threshold
    }
  }
  return(plates)
}


#' Get Barcode from plates.csv
#'
#' @param d description ("assay","on","agar")
#' @param p plate number
#' @param t transfer number
#' @section Output:
#'    a string of the barcode
#' @family hospital_experiment
#' @export
getBarcode <- function(d, p, t){
   plates_csv <- read.csv(paste0(output_directory, "/plates.csv"))
   plate <- subset(plates_csv, desc == d & n == p & transfer == t)
   return(plate$Barcode)
 }

################################################################################
# PLOT FUNCTIONS                                                               #
################################################################################

#' Plot transfers
#'
#' @param d description ("assay","on","agar")
#' @param p plate number
#' @param t transfer number
#' @section Output:
#'    a string of the barcode
#' @family hospital_experiment
#' @export
observedGraph <- function(plates, var, whichPlate){
  plates_list <- list()
  for (i in var$plates$plates){
    plates_list[[i]] <- plyr::ldply(plates[[i]])
    names(plates_list)[i] <- i
  }
  plates_df <- plyr::ldply(plates_list, .id = "plate")
  plot_data <- subset(plates_df, plate == whichPlate)

  plot_data$transfer_plot <- 0

  pheno_color <- var$pheno.table
  pheno_color$color <- c(
      "gray",     # gray     # 0001   0   1   E  TRUE
      "#0cb7eb",  # blue     # 0010   1   2   W  TRUE
      "#e53b6a",  # red      # 0011   2   3   F FALSE
      "#ebe507",  # yellow   # 0100   3   4   A  TRUE
      "#e53b6a",  # red      # 0101   4   5   F FALSE
      "#ffa10a",  # orange   # 0110   5   6   B  TRUE
      "#e53b6a",  # red      # 0111   6   7   F FALSE
      "#662f89",  # violett  # 1000   7   8 A/B  TRUE
      "#e53b6a",  # red      # 1001   8   9   F FALSE
      "#e53b6a",  # red      # 1010   9  10   F FALSE
      "#e53b6a",  # red      # 1011  10  11   F FALSE
      "#e53b6a",  # red      # 1100  11  12   F FALSE
      "#e53b6a",  # red      # 1101  12  13   F FALSE
      "#e53b6a",  # red      # 1110  13  14   F FALSE
      "#e53b6a",  # red      # 1111  14  15   F FALSE
      "#acdf0c")  # green    # 0000  15  16  AB  TRUE

  plot_data <- merge(plot_data, pheno_color[, c(2, 6)],
    by.x = "obs_phenotype", by.y = "int")

  plot_data <- arrange(plot_data, transfer, well)

  rep_dist <- 0.1

  for (i in 1:max(plot_data$rep)){
    plot_data[plot_data$rep == i, ]$transfer_plot <-
      plot_data[plot_data$rep == i, ]$transfer - 1.5 * rep_dist +
      (i - 1) * rep_dist
  }

  par(oma = c(0, 0, 0, 0), mar = c(2, 2, 2, 2))

  x_min <- 0 - 4 * rep_dist - 0.4
  x_max <- max(plot_data$transfer) + 4 * rep_dist

  plotTitle <- paste0(
    "Experiment ", var$times[var$times$event == "experiment_start", ]$barcode,
    " | Plate ", whichPlate, ", ",
    "Treatment: ", var$plates[whichPlate, ]$treatment
    )

  plot(1, xlim = c(x_min, x_max), ylim = c(0, 96),
    type = "n", xlab = "", ylab = "", axes = FALSE,
    main = plotTitle)
  axis(side = 1, at = 0:max(plot_data$transfer))
  legend_y <- 96 - 0:15 * 2
  legend2_y <- 96 - 17:26 * 2

  points(
    x = rep(x_min, 16),
    y = legend_y,
    pch = 19,
    col = pheno_color$color)
  text(
    x = rep(x_min, 16) + 0.1,
    y = legend_y,
    cex = 0.8,
    labels = pheno_color$let)

  pheno_letters <- str_c(c("E", "C", "F", "S", "U", "R", "P", "v", "V", "./*"),
    "  ")
  pheno_letters <- str_c(
      pheno_letters,
      c("Expected", "Contam", "Error?", "Tx success",
      "Tx unsucess", "denovo R", "rePlacement", "1xRevert",
      "2xRevert", "same/diff error"))
  text(
    x = rep(x_min, 10) - 0.1,
    y = legend2_y,
    pos = 4,
    cex = 0.8,
    labels = pheno_letters)

  points(
    x = plot_data$transfer_plot,
    y = well384toRepWell(plot_data$well),
    col = plot_data$color, pch = 15, cex = 1)
  points(
    x = plot_data$transfer_plot + rep_dist / 2,
    y = well384toRepWell(plot_data$well),
    col = "black", pch = plot_data$colony_class, cex = 0.5)

  for (i in unique(plot_data$transfer)){
    plot_data_transfer <- subset(plot_data, transfer == i & rep == 1)

    if (i > 0){
      load(paste0(output_directory, "/plate_transfer_", i, ".RData"))
    }

    # replacement
    replaced <- subset(plot_data_transfer,
      str_detect(plot_data_transfer$last_action, "replacement"))
    if (i > 0){
      replaced_strain <- subset(plate,
        well %in% replaced$well)$newStrain
    } else {
      replaced_strain <- replaced$strain
    }

    arrows(
      x0 = replaced$transfer - 3 * rep_dist,
      y0 = well384toRepWell(replaced$well),
      x1 = replaced$transfer - 2 * rep_dist,
      y1 = well384toRepWell(replaced$well),
      length = 0.05)
    text(
      x = replaced$transfer - 3 * rep_dist,
      y = well384toRepWell(replaced$well),
      labels = replaced_strain,
      pos = 2,
      cex = 0.6)
    # blanks
    blanks <- subset(plot_data_transfer,
      str_detect(plot_data_transfer$last_action, "blank"))

    points(
      x = blanks$transfer - 2 * rep_dist,
      y = well384toRepWell(blanks$well), pch = "*")

    # transfer
      transfered <- subset(plot_data_transfer,
      !(plot_data_transfer$last_action %in%
        c("replacement", "blank", "replacement & infection")))

      arrows(
        x0 = transfered$transfer - 1 + 2.5 * rep_dist,
        y0 = well384toRepWell(transfered$well),
        x1 = transfered$transfer - 2 * rep_dist,
        y1 = well384toRepWell(transfered$well),
        length = 0,
        lty = 2, col = "gray")
    # infection
      if (i > 0){
        infected <- subset(plot_data_transfer,
        str_detect(plot_data_transfer$last_action, "infection"))

        infected2 <- plate[plate$well %in% infected$well, ]

        arrows(
          x0 = infected$transfer - 1 + 2.5 * rep_dist,
          y0 = well384toRepWell(as.numeric(infected2$well)),
          x1 = infected$transfer - 2 * rep_dist,
          y1 = well384toRepWell(infected2$infectsWell),
          length = 0.05,
          lty = 1, col = "red")
      }
    # treatment
    if (i > 0){
      rect(xleft = plot_data_transfer$transfer - 0.5 - 0.05,
        ybottom = 0,
        xright = plot_data_transfer$transfer - 0.5 + 0.05,
        ytop = 97,
        col = "white",
        border = NA)
      text(
        x = plot_data_transfer$transfer - 0.5,
        y = well384toRepWell(plot_data_transfer$well),
        labels = plot_data_transfer$treatment, cex = 0.6)
    }
  }
}

#' plot huge diagnostic plot
#'
#' no description
#'
#' @param plate data.frame of single plate
#' @param t_cex relative size of text
#' @param p_cex relative size of points
#' @section Output:
#'    plot
#' @family hospital_experiment
#' @export
masterPlot <- function(plate, t_cex = 0.8, p_cex = 0.8){
  plate$row_int <- match(plate$row, LETTERS)
  os <- 0.25
  small_os <- os / 2
  par(oma = c(0, 0, 0, 0), mar = c(0, 2, 2, 0))
  #setup
  plot(1, xlim = c(1, 24), ylim = c(16, 1), type = "n",
    xlab = "", ylab = "", axes = FALSE)
  #axis and lines
    axis(side = 3, at = 1:24, labels = 1:24, lwd = 0)
    axis(side = 2, at = 1:16, labels = LETTERS[1:16], lwd = 0, las = 1)
    abline(h = 1:17 - 0.5, lwd = 0.1)
    abline(v = 1:25 - 0.5, lwd = 0.1)
    abline(h = c(1:17 - 0.5)[c(TRUE, FALSE)], lwd = 0.2)
    abline(v = c(1:25 - 0.5)[c(TRUE, FALSE)], lwd = 0.2)
  #od values
    points(plate$col - os, plate$row_int + os,
      col = .colorFun(plate$ODc, OD_threshold = attr(plate, "OD_threshold")),
      pch = 15, cex = 2)
  #od_class
    text(plate$col - os, plate$row_int + os,
      labels = plate$od_class, cex = t_cex)
  #col_class
    text(plate$col + os, plate$row_int - os,
      labels = plate$colony_class, cex = t_cex)
  # exp v. observed
    comparison_col <- rep("red", 384)
    comparison_col[plate$colony_class == "E"] <- "darkgreen"
    comparison_col[plate$colony_class %in% c("S", "U", "R", "P", "v", "V")] <-
      "orange"

    text(plate$col - os, plate$row_int - os,
      labels = str_c(
        plate$exp_phenotype_letters, "|", plate$obs_phenotype_letters),
      col = comparison_col,
      cex = t_cex)
  #colonies
    x_col <- plate$col + os
    y_col <- plate$row_int + os

    points(x_col - small_os, y_col - small_os,
      col = as.numeric(plate$gr_N), pch = 16, cex = p_cex)
    points(x_col + small_os, y_col - small_os,
      col = as.numeric(plate$gr_A), pch = 16, cex = p_cex)
    points(x_col - small_os, y_col + small_os,
      col = as.numeric(plate$gr_B), pch = 16, cex = p_cex)
    points(x_col + small_os, y_col + small_os,
      col = as.numeric(plate$gr_AB), pch = 16, cex = p_cex)
    rect(
      xleft = x_col - small_os,
      ybottom = y_col + small_os,
      xright = x_col + small_os,
      ytop = y_col - small_os)
  #treatment
    treatment_col <- rep(rgb(0.9, 0.9, 0.9, 0.5), 385)
    treatment_col[plate$treatment == "A"] <- rgb(1, 0, 0, 0.2)
    treatment_col[plate$treatment == "B"] <- rgb(0, 0, 1, 0.2)
    treatment_col[plate$treatment == "AB"] <- rgb(1, 0, 1, 0.2)
    rect(
      xleft = plate$col - 2 * os + 0.05,
      ybottom = plate$row_int + 2 * os - 0.05,
      xright = plate$col + 2 * os - 0.05,
      ytop = plate$row_int - 2 * os + 0.05,
      border = treatment_col, lwd = 3)
}

#' plot legend for huge diagnostic plot
#'
#' no description
#'
#' @section Output:
#'    plot
#' @family hospital_experiment
#' @export
masterPlotLegend <- function(){
  os <- 0.25
  small_os <- os / 2
  par(oma = c(0, 0, 0, 0), mar = c(0, 3.5, 2, 0))
  plot(1, xlim = c(0.5, 1.5), ylim = c(1.5, 0.5),
    type = "n", xlab = "", ylab = "", axes = FALSE)
  axis(side = 3, at = 1:1,
    labels = "COL", lwd = 0)
  axis(side = 2, at = 1:1,
    labels = "ROW", lwd = 0)
  abline(h = 1:2 - 0.5, lwd = 0.1)
  abline(v = 1:2 - 0.5, lwd = 0.1)
  text(1 - os, 1 - os,
    labels = "obs|exp", cex = 1)
  points(1 - os, 1 + os,
    col = .colorFun(0.1, 0.1), pch = 15, cex = 10)
  text(1 - os, 1 + os, labels = "OD\nOD_class", cex = 1)
  text(1 + os, 1 - os, labels = "colony_class", cex = 1)
  x_col <- 1 + os
  y_col <- 1 + os
  rect(
    xleft = x_col - small_os,
    ybottom = y_col + small_os,
    xright = x_col + small_os,
    ytop = y_col - small_os)
  points(x_col - small_os, y_col - small_os,
    col = "white", pch = 16, cex = 3)
  points(x_col + small_os, y_col - small_os,
    col = "white", pch = 16, cex = 3)
  points(x_col - small_os, y_col + small_os,
    col = "white", pch = 16, cex = 3)
  points(x_col + small_os, y_col + small_os,
    col = "white", pch = 16, cex = 3)
  text(x_col - small_os, y_col - small_os,
    labels = "N", cex = 1)
  text(x_col + small_os, y_col - small_os,
    labels = "A", cex = 1)
  text(x_col - small_os, y_col + small_os,
    labels = "B", cex = 1)
  text(x_col + small_os, y_col + small_os,
    labels = "AB", cex = 1)
  abline(h = 1 - 2 * os + 0.05,
    col = rgb(0.9, 0.9, 0.9, 0.5), lwd = 20)
  text(1, 1 - 2 * os + 0.05,
    labels = "treatment: none", cex = 1)
  abline(h = 1 + 2 * os - 0.05,
    col = rgb(1, 0, 1, 0.2), lwd = 20)
  text(1, 1 + 2 * os - 0.05,
    labels = "treatment: AB", cex = 1)
  abline(v = 1 - 2 * os + 0.05,
    col = rgb(1, 0, 0, 0.2), lwd = 20)
  text(1 - 2 * os + 0.05, 1,
    labels = "treatment: A", cex = 1, srt = 90)
  abline(v = 1 + 2 * os - 0.05,
    col = rgb(0, 0, 1, 0.2), lwd = 20)
  text(1 + 2 * os - 0.05, 1,
    labels = "treatment: B", cex = 1, srt = 90)
}

#' plot summary of readout from 4 agar plates (to check for errors)
#'
#' no description
#'
#' @param plate.readout list of 4 matrices (0:1) representing growth in "ab","b","a" and"no"
#' @param pheno.table table describing phenotypes
#' @section Output:
#'    plot
#' @family hospital_experiment
#' @export
plot_plate_readout <- function(plate.readout, pheno.table) {
  rows <- dim(plate.readout[[1]])[1]
  cols <- dim(plate.readout[[1]])[2]
  pheno <- get_pheno(plate.readout)
  par(mfrow = c(1, 1), mar = c(3, 3, 3, 5), xpd = TRUE,
    pin = c(cols / rows, 1) * 8)
  pchs <- c(0, 3, 4, 5)
  plot(c(1, cols), c(1, rows),
    type = "n", xaxt = "n", yaxt = "n", xlab = "cols", ylab = "rows",
    ylim = c(rows, 1), xlim = c(1, cols))
  axis(side = 2, at = 1:rows,
    labels = LETTERS[1:rows], las = 2)
  axis(side = 1, at = 1:cols,
    labels = 1:cols)
  for (row in 1:dim(pheno)[1]) {
    for (col in 1:dim(pheno)[2]) {
      for (i in 1:length(plate.readout)) {
        if (pheno.table$valid[pheno[row, col]]) {
          text(col, row, pheno.table$let[pheno[row, col]],
            cex = 0.8, offset = 0)
        } else {
          if (plate.readout[[i]][row, col] == 1) {
          points(col, row,
            col = "red", pch = pchs[i])
          }
        }
      }
    }
  }
  text(cols * 1.05, 0.5, "growth on", pos = 4, offset = 0)
  legend(cols * 1.05, 0.95, c("0", "A", "B", "AB"), pch = pchs, col = "red")
  title("Black: non-erroneous phenotypes; red: erroneous phenotypes")
}

#' plot change of phenotypes between to measurements (to check for unexpected results)
#'
#' no description
#'
#' @param pheno.expected matrix (16 x 24) of expected phenotypes
#' @param pheno.observed matrix (16 x 24) of observed phenotypes
#' @param treatment.matrix matrix (16 x 24) of treatment
#' @param transition.natrix possible transitions
#' @param pheno.table table describing phenotypes
#' @section Output:
#'    plot
#' @family hospital_experiment
#' @export
plot_pheno_change_agar <- function(
  pheno.expected,
  pheno.observed,
  treatment.matrix,
  transition.matrix,
  pheno.table){

  rows <- dim(pheno.expected)[1]
  cols <- dim(pheno.expected)[2]
  pheno.change <- compare_pheno_agar(pheno.expected, pheno.observed,
    transition.matrix, treatment.matrix, pheno.table)
  par(mfrow = c(1, 2), mar = c(3, 3, 3, 5), xpd = TRUE)
  col.treat <- c(
    rgb(0.9, 0.9, 0.9, 0.5),
    rgb(1, 0, 0, 0.2),
    rgb(0, 0, 1, 0.2),
    rgb(1, 0, 1, 0.2))
  plot(c(1, cols), c(1, rows),
    type = "n", xaxt = "n", yaxt = "n", xlab = "cols", ylab = "rows",
    ylim = c(rows, 1), xlim = c(1, cols))
  axis(side = 2, at = 1:rows,
    labels = LETTERS[1:rows], las = 2)
  axis(side = 1, at = 1:cols,
    labels = 1:cols)
  title(transition.matrix$legend,
    sub = "X=same error, .=different error (see compare.pheno)",
    cex.main = 0.8, cex.sub = 0.8)
  for (row in 1:dim(treatment.matrix)[1]) {
    for (col in 1:dim(treatment.matrix)[2]) {
      if (treatment.matrix[row, col] == "O")
        c <- col.treat[1]
      if (treatment.matrix[row, col] == "A")
        c <- col.treat[2]
      if (treatment.matrix[row, col] == "B")
        c <- col.treat[3]
      if (treatment.matrix[row, col] == "AB")
        c <- col.treat[4]
      rect(col - 0.4, row - 0.4, col + 0.4, row + 0.4,
        col = c, border = "NA")
      text(col, row, pheno.change[row, col],
        cex = 0.8, offset = 0)
    }
  }
  legend(cols * 1.05, 0.95, c("0", "A", "B", "AB"), pch = 15, col = col.treat)
  plot(c(1, cols), c(1, rows),
    type = "n", xaxt = "n", yaxt = "n", xlab = "cols", ylab = "rows",
    ylim = c(rows, 1), xlim = c(1, cols))
  axis(side = 2, at = 1:rows,
    labels = LETTERS[1:rows], las = 2)
  axis(side = 1, at = 1:cols,
    labels = 1:cols)
  for (row in 1:dim(treatment.matrix)[1]) {
    for (col in 1:dim(treatment.matrix)[2]) {
      if (treatment.matrix[row, col] == "O")
        c <- col.treat[1]
      if (treatment.matrix[row, col] == "A")
        c <- col.treat[2]
      if (treatment.matrix[row, col] == "B")
        c <- col.treat[3]
      if (treatment.matrix[row, col] == "AB")
        c <- col.treat[4]
      rect(col - 0.4, row - 0.4, col + 0.4, row + 0.4,
        col = c, border = "NA")
      text(col - 0.2, row + 0.2, pheno.table$let[pheno.expected[row, col]],
        cex = 0.6, offset = 0)
      text(col + 0.2, row - 0.2, pheno.table$let[pheno.observed[row, col]],
        cex = 0.6, offset = 0)
    }
  }
  legend(cols * 1.05, 0.95, c("0", "A", "B", "AB"), pch = 15, col = col.treat)
}

#' plot OD measurements
#'
#' no description
#'
#' @param pheno.current matrix (16 x 24) of expected phenotypes
#' @param phenoOD.observed matrix (16 x 24) of observed phenotypes
#' @param valueOD.observed matrix (16 x 24) of OD values
#' @param treatment.matrix matrix (16 x 24) of treatment
#' @param transition.natrix possible transitions
#' @param pheno.table table describing phenotypes
#' @section Output:
#'    plot
#' @family hospital_experiment
#' @export
plot_pheno_OD <- function(
  pheno.current,
  phenoOD.observed,
  valueOD.observed,
  treatment.matrix,
  transition.matrix,
  pheno.table){

  rows <- dim(pheno.current)[1]
  cols <- dim(pheno.current)[2]
  pheno.change <- compare_pheno_OD(pheno.current, phenoOD.observed,
    transition.matrix, treatment.matrix, pheno.table)
  par(mfrow = c(2, 2), mar = c(3, 3, 3, 5.5), xpd = TRUE)
  col.treat <- c(
    rgb(0.9, 0.9, 0.9, 0.5),
    rgb(1, 0, 0, 0.2),
    rgb(0, 0, 1, 0.2),
    rgb(1, 0, 1, 0.2))
  plot(c(1, cols), c(1, rows), type = "n", xaxt = "n", yaxt = "n",
    xlab = "cols", ylab = "rows",
    ylim = c(rows, 1), xlim = c(1, cols))
  axis(side = 2, at = 1:rows,
    labels = LETTERS[1:rows], las = 2)
  axis(side = 1, at = 1:cols,
    labels = 1:cols)
  title(transition.matrix$legend, cex.main = 0.8)
  for (row in 1:dim(treatment.matrix)[1]) {
    for (col in 1:dim(treatment.matrix)[2]) {
      if (treatment.matrix[row, col] == "O")
        c <- col.treat[1]
      if (treatment.matrix[row, col] == "A")
        c <- col.treat[2]
      if (treatment.matrix[row, col] == "B")
        c <- col.treat[3]
      if (treatment.matrix[row, col] == "AB")
        c <- col.treat[4]
      if (phenoOD.observed[row, col] == "G"){
        rect(col - 0.4, row - 0.4, col + 0.4, row + 0.4,
          col = c, border = "NA")
      }
      if (phenoOD.observed[row, col] == "N"){
        rect(col - 0.4, row - 0.4, col + 0.4, row + 0.4,
          col = "white", border = c)
      }
      if (pheno.change[row, col] != "E") {
        text(col, row, pheno.change[row, col], cex = 0.8, offset = 0)
      }
    }
  }
  legend(cols * 1.05, 0.95, c("0", "A", "B", "AB", "no grwth", "grwth"),
    pch = c(15, 15, 15, 15, 0, 15), col = c(col.treat, 1, 1))

  plot(c(1, cols), c(1, rows), type = "n", xaxt = "n", yaxt = "n",
    xlab = "cols", ylab = "rows", ylim = c(rows, 1), xlim = c(1, cols))
  axis(side = 2, at = 1:rows, labels = LETTERS[1:rows], las = 2)
  axis(side = 1, at = 1:cols, labels = 1:cols)

  for (row in 1:dim(treatment.matrix)[1]) {
    for (col in 1:dim(treatment.matrix)[2]) {
      if (treatment.matrix[row, col] == "O")
        c <- col.treat[1]
      if (treatment.matrix[row, col] == "A")
        c <- col.treat[2]
      if (treatment.matrix[row, col] == "B")
        c <- col.treat[3]
      if (treatment.matrix[row, col] == "AB")
        c <- col.treat[4]
      if (phenoOD.observed[row, col] == "G"){
        rect(col - 0.4, row - 0.4, col + 0.4, row + 0.4,
          col = c, border = "NA")
      }
      if (phenoOD.observed[row, col] == "N") {
        rect(col - 0.4, row - 0.4, col + 0.4, row + 0.4,
          col = "white", border = c)
      }
      text(col - 0.2, row + 0.2, pheno.table$let[pheno.current[row, col]],
        cex = 0.6, offset = 0)
      text(col + 0.2, row - 0.2, phenoOD.observed[row, col],
        cex = 0.6, offset = 0)
    }
  }

  legend(cols * 1.05, 0.95, c("0", "A", "B", "AB", "no grwth", "grwth"),
    pch = c(15, 15, 15, 15, 0, 15), col = c(col.treat, 1, 1))
  image(x = 1:24, y = 1:16, rescale(t(valueOD.observed)),
    xaxt = "n", yaxt = "n",
    ylim = c(rows + 0.5, 0.5), xlim = c(0.5, cols + 0.5),
    col = colorRampPalette(
      c("white", "green", "green4", "violet", "purple"))(100))
  axis(side = 2, at = 1:rows, labels = LETTERS[1:rows], las = 2)
  axis(side = 1, at = 1:cols, labels = 1:cols)
  for (row in 1:dim(treatment.matrix)[1]) {
    for (col in 1:dim(treatment.matrix)[2]) {
      text(col, row, signif(valueOD.observed[row, col], digits = 3))
    }
  }
}

#' plots a 4x4 representation of a well across all 4 replicates
#'
#' no description
#'
#' @param x x coordinate
#' @param y y coordinate
#' @param size of square
#' @param well_df subset data.frame form plates of the well
#' @param gap gap between replicate squares
#' @param pheno_colors data.frame with phenotypes and colors (=var$pheno.table)
#' @param cex cex used for text
#' @param label should the well number be printed above the square?
#' @section Output:
#'    an integer
#' @family hospital_experiment
#' @export
plot_wellrep <- function(x, y, size, well_df,
  gap = 0,
  pheno_colors = var$pheno.table,
  cex = 1,
  label = TRUE){
  repwell <- arrange(well_df, rep) %>%
    group_by(well) %>%
    mutate(
      plot_color = pheno_colors$color[pheno_colors$bin == obs_phenotype_bin])
  halfgap <- (gap * size) / 2
  halfsize <- size / 2
  squaresize <- halfsize - halfgap
  rect_args <- list(
    xleft = rep(c(x - halfsize, x + halfgap), 2),
    xright = rep(c(x - halfgap, x + halfsize), 2),
    ytop = rep(c(y + halfsize, y - halfgap), each = 2),
    ybottom = rep(c(y + halfgap, y - halfsize), each = 2),
    col = repwell$plot_color
    )
  do.call(rect, rect_args)
  text(
    x = rect_args$xleft + squaresize / 2,
    y = rect_args$ytop - squaresize / 2,
    labels = repwell$colony_class,
    cex = cex)
  if (label){
    text(
    x = x,
    y = y + halfsize,
    labels = repwell$repwell,
    pos = 3, cex = cex
    )
  }
}

#' plots the history of 1 repwell (i.e. 4 wells)
#'
#' no description
#'
#' @param plot_well focus well
#' @param plate on which plate
#' @param data list produced by evoware
#' @param legend should a legend be plotted?
#' @param box_size size of boxes
#' @param box_gap gap between boxes
#' @param box_dist distance of other elements from boxes
#' @param cex scale of text
#' @section Output:
#'    plot elements
#' @family hospital_experiment
#' @export
wellPlot <- function(plot_well, plate, data = plates,
  legend = TRUE,
  y = 0,
  pheno_table = var$pheno.table,
  box_size = 1,
  box_gap  = box_size,
  box_dist = 0.1 * box_size,
  cex = 0.75){

  plot_data <- plyr::ldply(data[[plate]], .id = "transfer")

  # legend
  if(legend){
    pheno_legend <- pheno_table[!duplicated(pheno_table$color), ]
    pheno_legend$let <- factor(pheno_legend$let,
      levels = c("E", "W", "A", "B", "AB", "A/B", "F"))
    pheno_legend[order(pheno_legend$let), ]
    n_legend  <- length(pheno_legend$color)
    box_size_legend <- box_size / 3
    legend_x <- mean(par("usr")[1:2])
    legend_y <- min(par("usr")[3:4]) + 2 * box_size_legend
    # legend boxes
    xleft <- legend_x - (n_legend - 0.5) * box_size_legend +
      0:(n_legend - 1) * 2 * box_size_legend
    legend_args <- list(
      xleft = xleft,
      xright = xleft + box_size_legend,
      ytop = legend_y + 0.5 * box_size_legend,
      ybottom = legend_y - 0.5 * box_size_legend,
      col = pheno_legend$color
      )
    do.call(rect, legend_args)
    text(x = legend_args$xleft[1],
      y = (legend_args$ytop[1] + legend_args$ybottom[1]) / 2,
      labels = "Phenotypes",
      pos = 2, cex = cex
      )
    text(x = legend_args$xright,
      y = (legend_args$ytop + legend_args$ybottom) / 2,
      labels = pheno_legend$let,
      pos = 4, cex = cex
      )
    arrow_len <- 2 * box_size_legend
    arrow_x0 <- legend_x - 3.5 * arrow_len + 0:3 * 2 * arrow_len
    arrows(x0 = arrow_x0, x1 = arrow_x0 + arrow_len,
      y0 = min(ylimits), y1 = min(ylimits),
      col = c("black", "darkblue", "orange", "red"),
      lwd = 2, length = cex * box_size / 8)
    text(x = arrow_x0 + arrow_len * 0.5, y = min(ylimits),
      labels = c("transfer", "replacement", "-> infection", "<- infection"),
      pos = 3, cex = cex)
  }


  for (i in 0:max(plot_data$transfer)){
    plot_data_wt <- filter(plot_data, repwell == plot_well, transfer == i)
    boxpos <- i * box_size * 2
    last_boxpos <- (i - 1) * box_size * 2
    text(x = -2 * box_size, y = y,
      labels = paste("Well", plot_well),
      cex = 1.5*cex, pos = 4)
    # focus well
    plot_wellrep(x = boxpos, y = y,
      size = box_size, well_df = plot_data_wt, cex = cex, label = FALSE)
    # replacement
    if (str_detect(plot_data_wt$last_action[1], "replacement")){
      arrow_x0 <- last_boxpos + 0.5 * box_size + box_dist
      arrow_y0 <- y - box_size + box_dist
      arrows(
        x0 = arrow_x0, y0 = arrow_y0,
        x1 = boxpos - 0.5 * box_size - box_dist,
        y1 = y - 0.5 * box_size - box_dist,
        lwd = 2, length = cex * box_size / 8, col = "darkblue")
      text(x = arrow_x0, y = arrow_y0,
        labels = plot_data_wt$la_replacement_by[1],
        pos = 2, cex = cex)
    }
    # transfer
    if (str_detect(plot_data_wt$last_action[1], "transfer")){
      arrows(
        x0 = last_boxpos + 0.5 * box_size + box_dist, y0 = y,
        x1 = i * box_size * 2 - box_size * 0.6, y1 = y,
        lwd = 2, length = cex * box_size / 8)
    }
    # infects other well
    if (str_detect(plot_data_wt$last_action[1], "infection")){
      arrows(
        x0 = last_boxpos + 0.5 * box_size + box_dist, y0 = y,
        x1 = i * box_size * 2 - box_size * 0.6, y1 = y, lwd = 2,
        length = cex * box_size / 8)
      arrow_x0 <- last_boxpos + 0.5 * box_size + box_dist
      arrow_y0 <- y
      arrows(
        x0 = arrow_x0, y0 = arrow_y0,
        x1 = boxpos - 0.5 * box_size - box_dist,
        y1 = y - box_size,
        lwd = 2, length = box_size / 8, col = "orange")
    }
    # is infected
    if (!is.na(plot_data_wt$la_infection_from[1])){
      infected_from <- well384toRepWell(plot_data_wt$la_infection_from[1])
      plot_data_infsource <- filter(plot_data,
        repwell == infected_from, transfer == i - 1)
      plot_wellrep(x = last_boxpos, y = y + 2 * box_size,
        size = box_size, well_df = plot_data_infsource, cex = cex)
      arrow_x0 <- last_boxpos + 0.5*box_size + box_dist
      arrow_y0 <- y + 2 * box_size
      arrows(
        x0 = arrow_x0, y0 = arrow_y0,
        x1 = boxpos - 0.5 * box_size - box_dist,
        y1 = y + 0.5 * box_size + box_dist,
        lwd = 2, length = box_size / 8,
        col = "red")
    }
    # treatment
    if (i > 0){
      text(
        x = (boxpos + last_boxpos)/2,
        y = y,
        labels = plot_data_wt$treatment[1],
        pos = 3
      )
    }
  }
}

################################################################################
# ACCESSORY FUNCTIONS                                                          #
################################################################################

#' growth in drugs to integer
#'
#' given growth in 4 conditions returns the integer of the corresponding
#' binary value. e.g. TRUE,FALSE,TRUE,TRUE => 1011 => 13
#'
#' @param N growth in N? (logical)
#' @param A growth in A? (logical)
#' @param B growth in B? (logical)
#' @param AB growth in AB? (logical)
#' @section Output:
#'    an integer
#' @family hospital_experiment
#' @export
growthToPhe_int <- function(N, A, B, AB){
  vector <- c(N, A, B, AB)
  out <- sum(vector * 2 ^ (0:(length(vector) - 1)))
  return(out)
}


#' get integer phenotype from amtrices
#'
#' no description
#'
#' @param plate.readout list of 4 matrices named no, a, b and ab
#' @section Output:
#'    a matrix with integer phenotypes
#' @family hospital_experiment
#' @export
get_pheno <- function(plate.readout){
  plate.readout[[1]] + 2 * plate.readout[[2]] +
    4 * plate.readout[[3]] + 8 * plate.readout[[4]] + 1
}


#' compare expected and observed phenotype measurements on agar (as a function of expectations based on transition matrix)
#'
#' no description
#'
#' @param pheno.expected matrix (16 x 24) of expected phenotypes
#' @param pheno.observed matrix (16 x 24) of observed phenotypes
#' @param treatment.matrix matrix (16 x 24) of treatment
#' @param transition.natrix possible transitions
#' @param pheno.table table describing phenotypes
#' @section Output:
#'    a matrix
#' @family hospital_experiment
#' @export
compare_pheno_agar <- function(
  pheno.expected,
  pheno.observed,
  transition.matrix,
  treatment.matrix,
  pheno.table){

  rows <- dim(pheno.expected)[1]
  cols <- dim(pheno.expected)[2]
  pheno.change <- matrix("NA", rows, cols)

  for (r in 1:rows){
    for (c in 1:cols){
      # handle erroneous phenotypes
      if (pheno.expected[r, c] %in% pheno.table$ind[!pheno.table$valid]) {
        pheno.change[r, c] <- "."
      }
      if (pheno.observed[r, c] %in% pheno.table$ind[!pheno.table$valid]) {
        pheno.change[r, c] <- "."
      }
      if (pheno.observed[r, c] %in% pheno.table$ind[!pheno.table$valid] &
        pheno.expected[r, c] == pheno.observed[r, c]) {
        pheno.change[r, c] <- "*"
      }
      if (pheno.expected[r, c] %in% pheno.table$ind[pheno.table$valid] &
        pheno.observed[r, c] %in% pheno.table$ind[pheno.table$valid]) {
         pheno.change[r, c] <- transition.matrix[[treatment.matrix[r, c]]][pheno.table$let[pheno.expected[r, c]], pheno.table$let[pheno.observed[r, c]]]
      }
    }
  }
  pheno.change
}

#' compare expected and observed phenotype measurements on OD (as a function of expectations based on transition matrix)
#'
#' no description
#'
#' @param pheno.current matrix (16 x 24) of expected phenotypes
#' @param phenoOD.observed matrix (16 x 24) of observed phenotypes
#' @param treatment.matrix matrix (16 x 24) of treatment
#' @param transition.natrix possible transitions
#' @param pheno.table table describing phenotypes
#' @section Output:
#'    placeholder placeholder
#' @family hospital_experiment
#' @export
compare_pheno_OD <- function(
  pheno.current,
  phenoOD.observed,
  transition.matrix,
  treatment.matrix,
  pheno.table){

  rows <- dim(pheno.current)[1]
  cols <- dim(pheno.current)[2]
  pheno.change <- matrix("NA", rows, cols)
  for (r in 1:rows){
    for (c in 1:cols){
      # handle erroneous phenotypes
      if (pheno.current[r, c] %in% pheno.table$ind[!pheno.table$valid]) {
        pheno.change[r, c] <- "."
      } else {
        pheno.change[r, c] <-
        transition.matrix[[treatment.matrix[r, c]]][pheno.table$let[pheno.current[r, c]], phenoOD.observed[r, c]]
      }
    }
  }
  pheno.change
}

#' Generate list of matrices (0:1) for Sebs Plot functions from phenotype vector (0:15)
#'
#' no description
#'
#' @param obs_phenotype vector with 0:15 phenotypes, length 384
#' @section Output:
#'    list of 4 matrices named no, a, b and ab -> plate.readout
#' @family hospital_experiment
#' @export
vP_to_lm  <- function(obs_phenotype){
  obs_phenotype_df <- plyr::ldply(
    str_split(intToBin(obs_phenotype), ""),
    function(x){
      rbind(as.numeric(x))
    })
  names(obs_phenotype_df) <- c("ab", "b", "a", "no")
  out <- plyr::llply(as.list(obs_phenotype_df[, 4:1]),
    .fun = function(x){
      matrix(x, ncol = 24, byrow = TRUE)
    })
  return(out)
}

#' Generate matrix (1:16) for Sebs Plot functions from phenotype vector (0:15)
#'
#' no description
#'
#' @param obs_phenotype vector with 0:15 phenotypes, length 384
#' @section Output:
#'    matrix with phenotype from 1:16
#' @family hospital_experiment
#' @export
vP_to_m  <- function(obs_phenotype){
  obs_phenotype_m <- matrix(obs_phenotype + 1, ncol = 24, byrow = TRUE)
  return(obs_phenotype_m)
}

#' Generate matrix for Sebs Plot functions from OD growth vector (logical)
#'
#' no description
#'
#' @param od_phenotype logical
#' @section Output:
#'    matrix with od phenotype (G,N)
#' @family hospital_experiment
#' @export
vO_to_m  <- function(od_phenotype){
  od_phenotype_c <- od_phenotype
  od_phenotype_c[od_phenotype] <- "G"
  od_phenotype_c[!od_phenotype] <- "N"
  od_phenotype_m <- matrix(od_phenotype_c, ncol = 24, byrow = TRUE)
  return(od_phenotype_m)
}

#' Generate matrix for Sebs Plot functions from treatment vector
#'
#' no description
#'
#' @param treatment vector with "A", "B","AB","none", length 384
#' @section Output:
#'    matrix with treatment
#' @family hospital_experiment
#' @export
vT_to_m  <- function(treatment){
  treatment <- as.character(treatment)
  treatment[treatment == "none"] <- "O"
  treatment_m <- matrix(treatment, ncol = 24, byrow = TRUE)
  return(treatment_m)
}

#' Get classification for observed change in phenotype from colonies
#'
#' no description
#'
#' @param observed_let letter code for the observed phenotype
#' @param expected_let letter code for the expected phenotype
#' @param treatment treatment, one of "none","A","B","AB"
#' @param changeMat matrix of possible changes
#' @section Output:
#'    classification (string)
#' @family hospital_experiment
#' @export
phenoChangeClassColony <- function(
  observed_let,
  expected_let,
  treatment,
  changeMat = var$pheno.change.agar.matrix){

  treat_df <- data.frame(
    treat = c("none", "A", "B", "AB"),
    treat_short = c("O", "A", "B", "AB"),
    treat_n = c(1, 2, 3, 4),
    stringsAsFactors = FALSE)
  treat_n <- treat_df[treat_df$treat == as.character(treatment), ]$treat_n

  if (is.na(observed_let)){
    return(NA)
  } else if (observed_let == "F" | expected_let == "F"){
    return("F")
  } else {
    return(changeMat[[treat_n]][expected_let, observed_let])
  }
}


#' Get classification for observed change in phenotype from OD
#'
#' no description
#'
#' @param observed_OD OD values
#' @param OD_threshold what is growth?
#' @param expected_let letter code for the expected phenotype
#' @param treatment treatment, one of "none","A","B","AB"
#' @param changeMat matrix of possible changes
#' @section Output:
#'    classification (string)
#' @family hospital_experiment
#' @export
phenoChangeClassOD <- function(observed_OD,
  OD_threshold=0.01,
  expected_let,
  treatment,
  changeMat = var$pheno.change.OD.matrix){

  if (is.na(observed_OD)){
    return(NA)
  }
  treat_df <- data.frame(
    treat = c("none", "A", "B", "AB"),
    treat_short = c("O", "A", "B", "AB"),
    treat_n = c(1, 2, 3, 4),
    stringsAsFactors = FALSE)
  treat_n <- treat_df[treat_df$treat == as.character(treatment), ]$treat_n

  if(observed_OD > OD_threshold){
    observed_let <- "G"
  } else {
    observed_let <- "N"
  }

  if (expected_let == "F"){
    return("F")
  } else {
    return(changeMat[[treat_n]][expected_let, observed_let])
  }
}

#' Did a colony grow in drug AB?
#'
#' accounting for manual correction
#'
#' @param pickolo_phenotype data.frame of colony observations (for all drugs)
#' @param ab drug one of "N","A","B","AB"
#' @section Output:
#'    logical
#' @family hospital_experiment
#' @export
growthInAB <- function(pickolo_phenotype, ab){
  pheno_ab <- subset(pickolo_phenotype, abx == ab)
  growth <- pheno_ab$growth
  growth[!is.na(pheno_ab$manual)] <- pheno_ab$manual[!is.na(pheno_ab$manual)]
  return(growth)
}

#' Color for OD values such that threshold is orange
#'
#' no description
#'
#' @param ODc corrected ODs
#' @param OD_threshold what is growth?
#' @section Output:
#'    vector of colors
#' @family hospital_experiment
#' @export
.colorFun <- function(ODc, OD_threshold){
  c <- list()
  for (i in seq_along(ODc)){
    if (ODc[i] < 1.1 * OD_threshold){
      c[[i]] <- rgb(
        colorRamp(
          colors = c("white", "gold"),
          space = "rgb",
          interpolate = "linear")(rescale(ODc[i], from = range(ODc))
        ) / 255,
        alpha = 0.5)
    } else {
      c[[i]] <- rgb(
        colorRamp(
          colors = c("gold", "blue"),
          space = "rgb",
          interpolate = "linear")(rescale(ODc[i], from = range(ODc))
        ) / 255,
        alpha = 0.5)
    }
  }
  return(unlist(c))
}

#' Well on 384 plate to well in virtual 96 well plate replicate
#'
#' no description
#'
#' @param x vector of wells (integer 1:384)
#' @section Output:
#'    vector of well (integer 1:96)
#' @family hospital_experiment
#' @export
well384toRepWell <- function(x){
  index <- rep(0, length(x))
  for (i in seq_along(x)){
    index[i] <- which(as.matrix(var$wells_rep) == x[i], arr.ind = TRUE)[1, 1]
  }
  return(index)
}
