#' rrobot.
#' A package containing tools for worklist generation for the freedom evo.
#'
#'
#'@section General methods:
#'
#'      \code{\link{gen_turnover}}
#'
#'      \code{\link{gen_treatment}}
#'@name rrobot
#'@docType package
NULL