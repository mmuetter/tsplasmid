#' get number of observations
#'
#'
#' @param x a vector
#' @family analysis
#' @export
ens <- function(x) {
  sum(!is.na(x))
}

#' get standard error
#'
#'
#' @param x a vector
#' @family analysis
#' @export
se <- function(x) {
  se <- sd(x, na.rm = TRUE) / sqrt(ens(x))
}


#' Get experiment
#'
#' get the key data for an experiment
#'
#' @param exp_id experiment id or NULL
#' @param exp_name experiment_name, only used if exp_id is not provided
#' @family analysis
#' @export
get_experiment <- function(exp_id = NULL, exp_name = NULL, dir) {

  experiments <- read_csv(str_c(dir, "experiments.csv"),
    col_types = cols(
      id = col_integer(),
      created = col_datetime(format = ""),
      output_directory = col_character(),
      exp_name = col_character()))
  if (is.null(exp_id)) {
    if (is.null(exp_name)) {
      stop("provide either exp_id or exp_name!")
    } else {
      experiment <- filter(experiments, output_directory == exp_name)
    }
  } else {
    experiment <- filter(experiments, id == exp_id)
  }
  if (dim(experiment)[1] > 1) {
    warning("more than one experiment found!")
  } else if (dim(experiment)[1] == 0) {
    warning("no experiment found!")
  } else {
    experiment$path <- str_c(dir, experiment$output_directory)
  }
  return(experiment)
}

#' Get experiment data
#'
#' get the data for an experiment
#'
#' @param exp output of get_experiment()
#' @param od_cutoff arbitrary cutoff representing growth
#' @family analysis
#' @export
get_experiment_data <- function(exp, od_cutoff = 0.1) {
  transfers <- read_csv(str_c(exp$path, "/transfers.csv"),
    col_types = cols(
      n = col_integer(),
      run = col_integer(),
      created = col_datetime(format = ""),
      type = col_character())) %>%
    # choose transfers to analyse, i.e the ones with max(run)
    group_by(n) %>%
    top_n(1, run) %>%
    mutate(transfer_id = str_c(n, run, sep = "_"))

  barcodes <- read_csv(
    str_c(exp$path, "/barcodes.csv"),
    col_types = cols(
      transfer = col_integer(),
      run = col_integer(),
      desc = col_character(),
      plate_n = col_integer(),
      barcode = col_character(),
      ab = col_character())) %>%
    mutate(transfer_id = str_c(transfer, run, sep="_")) %>%
    filter(transfer_id %in% transfers$transfer_id)

  # plates data
  plates_path <- str_c(exp$path, "/platefiles")
  plates_paths <- list.files(path = plates_path, full.names = TRUE, pattern = ".csv")
  plates_data_lst <- lst()
  for (i in seq_along(plates_paths)){
    plates_data_lst[[i]] <- read_csv(plates_paths[i],
      col_types = cols(
        plate = col_integer(),
        well = col_integer(),
        row = col_character(),
        col = col_integer(),
        tip = col_integer(),
        rep = col_integer(),
        rwell = col_integer(),
        transfer_n = col_integer(),
        turnover_strain = col_character(),
        transfer_to_well = col_integer(),
        infection_to_well = col_integer(),
        treatment_with = col_character())) %>%
    left_join(tibble(row = LETTERS[1:16], row_int = 1:16),
      by = "row")
  }
  plates_data <- bind_rows(plates_data_lst)

  # od_data
  od_path <- str_c(exp$path, "/od/xml")
  od_paths <- list.files(path = od_path, pattern = ".xml",)
  od_paths_df <- as_tibble(str_split(od_paths, "t|_|P|.xml", simplify = TRUE)) %>%
    transmute(
      barcode = V7,
      transfer_n = as.integer(V2),
      plate = as.integer(V4),
      abx = V5,
      type = V6,
      path = str_c(od_path, "/", od_paths)) %>%
    filter(barcode %in% barcodes$barcode)

  od_data_lst <- lst()
  for (i in od_paths_df$path){
    od_data_lst[[i]] <- readInfiniteXML(i)$data %>%
      rename(
        barcode = plate) %>%
      mutate(type = str_sub(i, start=-17, end=-16)) %>%
      left_join(tibble(row = LETTERS[1:16], row_int = 1:16),
        by = "row")
  }
  od_data <- as_tibble(bind_rows(od_data_lst)) %>%
    left_join(select(od_paths_df, -path), by = c("barcode", "type"))

  # pickolo_data
  pickolo_path <- str_c(exp$path, "/pickolo/json")
  pickolo_paths <- list.files(path = pickolo_path, pattern = ".json")
  pickolo_paths_df <- as_tibble(str_split(pickolo_paths, "t|_|P|.json", simplify = TRUE)) %>%
    transmute(
      barcode = V6,
      transfer_n = as.integer(V2),
      plate = as.integer(V4),
      abx = V5,
      path = str_c(pickolo_path, "/", pickolo_paths)) %>%
    filter(barcode %in% barcodes$barcode)

  pickolo_data_lst <- lst()
  for (i in seq_along(pickolo_paths_df$path)){
    pickolo_data_lst[[i]] <- fromJSON(pickolo_paths_df$path[i])$growth %>%
      transmute(
        plate = pickolo_paths_df$plate[i],
        transfer_n = pickolo_paths_df$transfer_n[i],
        barcode = pickolo_paths_df$barcode[i],
        abx = pickolo_paths_df$abx[i],
        row = row,
        col = col,
        well = well,
        growth = growthcombine(auto, manual)
        ) %>%
      left_join(tibble(row = LETTERS[1:16], row_int = 1:16),
        by = "row")
  }
  pickolo_data <- as_tibble(bind_rows(pickolo_data_lst)) %>%
    select(-barcode) %>%
    spread(abx, growth) %>%
    mutate(
      phenotype = growthToPhenotype(N, A, B, AB)) %>%
    left_join(phenotype_table$phenotypes, by = c("phenotype" = "int"))

  all_data <- plates_data %>%
    left_join(
      select(filter(od_data, type == "AI"),
        plate, row_int, col, well, transfer_n, OD),
        by = c("plate", "well", "col", "transfer_n", "row_int")) %>%
    left_join(
      select(pickolo_data,
        plate, row_int, col, well, transfer_n, phenotype),
        by = c("plate", "well", "col", "transfer_n", "row_int")) %>%
    arrange(transfer_n, plate, well) %>%
    # add phenotype32
    mutate(OD_growth = OD >= od_cutoff,
      phenotype32 = phenotype + OD_growth * 16,
      llRA = OD_growth & treatment_with == "A",
      llRB = OD_growth & treatment_with == "B",
      llRAB = OD_growth & treatment_with == "AB",
      phenotype256 = phenotype32 + llRA * 32 + llRB * 64 + llRAB * 128,
      last_phenotype = dplyr::lag(phenotype, length(unique(plate)) * 384),
      last_phenotype32 = dplyr::lag(phenotype32, length(unique(plate)) * 384),
      last_phenotype256 = dplyr::lag(phenotype256, length(unique(plate)) * 384)) %>%
    select(-llRA, -llRB, -llRAB)
  
  # turnover phenotype
    all_data$turnover_phenotype <- phenotype_table$strains$phenotype[
      match(all_data$turnover_strain, phenotype_table$strains$strain)]
      # first transfer: last_phenotype == turnover_phenotype
      all_data$last_phenotype[all_data$transfer_n == 0] <-
         all_data$turnover_phenotype[all_data$transfer_n == 0]
    all_data$turnover_phenotype32 <- phenotype_table$strains$phenotype32[
      match(all_data$turnover_strain, phenotype_table$strains$strain)]
      # first transfer: last_phenotype == turnover_phenotype
      all_data$last_phenotype32[all_data$transfer_n == 0] <-
         all_data$turnover_phenotype32[all_data$transfer_n == 0]
    all_data$turnover_phenotype256 <- phenotype_table$strains$phenotype256[
      match(all_data$turnover_strain, phenotype_table$strains$strain)]
      # first transfer: last_phenotype == turnover_phenotype
      all_data$last_phenotype256[all_data$transfer_n == 0] <-
         all_data$turnover_phenotype256[all_data$transfer_n == 0]
  # transfer phenotype = last phenotype
    all_data$transfer_phenotype <- dplyr::lag(all_data$phenotype,
      n = length(unique(all_data$plate)) * 384)
    all_data$transfer_phenotype[is.na(all_data$transfer_to_well)] <- NA
    all_data$transfer_phenotype32 <- dplyr::lag(all_data$phenotype32,
      n = length(unique(all_data$plate)) * 384)
    all_data$transfer_phenotype32[is.na(all_data$transfer_to_well)] <- NA
    all_data$transfer_phenotype256 <- dplyr::lag(all_data$phenotype256,
      n = length(unique(all_data$plate)) * 384)
    all_data$transfer_phenotype256[is.na(all_data$transfer_to_well)] <- NA
  # infection phenotype
    infecting_wells <- all_data %>%
      mutate(
        infection_phenotype = dplyr::lag(phenotype, length(unique(plate)) * 384),
        infection_phenotype32 = dplyr::lag(phenotype32, length(unique(plate)) * 384),
        infection_phenotype256 = dplyr::lag(phenotype256, length(unique(plate)) * 384)
        ) %>%
      filter(!is.na(infection_to_well)) %>%
      mutate(infection_from_well = rwell) %>%
      select(plate, rep, transfer_n, infection_to_well, infection_phenotype,
        infection_phenotype32, infection_phenotype256, infection_from_well)
    all_data <- all_data %>%
      left_join(infecting_wells,
        by = c("plate", "rep", "transfer_n", "rwell" = "infection_to_well"))

  # phenotype expected by simple mixing phenotype
    all_data$mix_phenotype <- mixPhenotype(
      all_data$turnover_phenotype,
      all_data$transfer_phenotype,
      all_data$infection_phenotype)
  # classification
    all_data <- all_data %>%
      left_join(select(phenotype_table$changes_agar, treatment:post_int),
        by = c(
          "treatment_with" = "treatment",
          "phenotype" = "post_int",
          "mix_phenotype" = "pre_int")) %>%
      replace_na(replace = list(class_short = "F")) %>%
      left_join(select(phenotype_table$changes_legend, -color),
        by = "class_short")
  # labels
    all_data$labels <- all_data$turnover_strain
    all_data$labels[is.na(all_data$turnover_strain)] <-
      str_c("T(",
        all_data$last_phenotype[is.na(all_data$turnover_strain)], ")")
    all_data$labels[!is.na(all_data$infection_phenotype)] <-
      str_c("I(",
        all_data$infection_phenotype[!is.na(all_data$infection_phenotype)],
        ")")


    return(list(
      transfers = transfers,
      barcodes = barcodes,
      plates_data = plates_data,
      od_data = od_data,
      pickolo_data = pickolo_data,
      all_data = all_data))

}

#' Export Transfer Data for Antoines model
#'
#' Export data in json format such that antoines model can use it
#'
#' @param plates_data plates_data from get_experiment_data
#' @param pars experiment_parameters
#' @param output_path folder to save output too.
#' @family analysis
#' @export
export_antoine_sim <- function(plates_data, pars, output_path){
  id_table <- tibble(
    rwell = pars$format$rwells_p[[1]],
    id = 1:94)
  translation_table <- tibble(
    strain = c("wt", "UI", "A_r", "B_r", "AB_r"),
    type = c("S1S2", "none", "R1S2", "S1R2", "R1R2"))
  transfers <- bind_rows(plates_data) %>%
    left_join(id_table, by = "rwell") %>%
    filter(plate == 1, rep == 1, !is.na(id)) %>%
    arrange(transfer_n, rwell)
  init <- transfers %>% 
    filter(transfer_n == 0, rep == 1) %>%
    left_join(translation_table, by = c("turnover_strain" = "strain")) %>%
    select(type)
  init <- as.list(init[[1]])
  names(init) <- 1:94

  turnover1 <- transfers %>%
    filter(rep == 1, !is.na(turnover_strain)) %>%
    left_join(translation_table, by = c("turnover_strain" = "strain")) %>%
    select(transfer_n, id, type)
  turnover1 <- split(turnover1, turnover1$transfer_n)
  turnover <- lst()
  for (i in seq_along(turnover1)) {
    turnover[[i]] <- as.list(turnover1[[i]]$type)
    names(turnover[[i]]) <- turnover1[[i]]$id
  }
  infection1 <- transfers %>%
    filter(transfer_n != 0, rep == 1, !(is.na(infection_to_well))) %>%
    select(transfer_n, id, infection_to_well) %>%
    left_join(id_table, by = c("infection_to_well" = "rwell")) %>%
    select(transfer_n, id.x, id.y) %>%
    rename(id_s = id.x, id_d = id.y)
  infection1 <- split(infection1, infection1$transfer_n)
  infection1 <- append(infection1,
    list("0" = tibble(id_s = integer(0), id_d = integer(0))), 0)
  infection <- lst()
  for (i in seq_along(infection1)) {
    infection[[i]] <- as.list(infection1[[i]]$id_d)
    names(infection[[i]]) <- infection1[[i]]$id_s
  }

  simfile <- lst(
    "1" = turnover,
    "2" = infection)
  write(toJSON(simfile, pretty = TRUE, auto_unbox = TRUE), file.path(output_path, "transfers.json"))

  # write parameter file
  std_sim_parameter$parameter$infection_rate <- pars$rates$infection
  std_sim_parameter$parameter$turnover_rate <- pars$rates$turnover
  std_sim_parameter$parameter$ndays <- max(plates_data$transfer_n)+1
  std_sim_parameter$parameter$nhosts <- pars$format$n_patients
  std_sim_parameter$parameter$community_s1s2 <- pars$community$n[4]
  std_sim_parameter$parameter$community_s1r2 <- pars$community$n[3]
  std_sim_parameter$parameter$community_r1s2 <- pars$community$n[2]
  std_sim_parameter$parameter$community_r1r2 <- pars$community$n[1]
  std_sim_parameter$parameter$community_u <- pars$community$n[5]
  std_sim_parameter$parameter$strategy_style <- pars$treatment$conditions_name
  drug_ratio1 <- rep(0, length(pars$treatments$plate))
  drug_ratio2 <- rep(0, length(pars$treatments$plate))
  for (i in seq_along(drug_ratio1)){
    if ("A" %in% pars$treatments$drugs[[i]] | "AB" %in% pars$treatments$drugs[[i]]){
      drug_ratio1[i] <- 1
    }
    if ("B" %in% pars$treatments$drugs[[i]] | "AB" %in% pars$treatments$drugs[[i]]){
      drug_ratio2[i] <- 1
    }
  }
  std_sim_parameter$parameter$ratio_drug1 <- drug_ratio1
  std_sim_parameter$parameter$ratio_drug2 <- drug_ratio2
  std_sim_parameter$parameter$period <- pars$treatment$period[pars$treatment$conditions_name == "cycling"]
  std_sim_parameter$parameter$mixratio <- pars$treatment$probability[pars$treatment$conditions_name == "mixing"][[1]][1]
  write(toJSON(std_sim_parameter, pretty = TRUE, auto_unbox = TRUE), file.path(output_path, "parameter.json"))
}
