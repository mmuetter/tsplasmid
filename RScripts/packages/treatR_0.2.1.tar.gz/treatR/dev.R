library(devtools)
library(tidyverse)
library(ggplot2)
library(jsonlite)

document()
packagePath <- build()
install.packages(packagePath)

polybox_path <- "/Users/daniel/polybox/Robot-Shared/TSPlasmids/RScripts/packages/"
file.copy(
  from = packagePath,
  to = stringr::str_c(polybox_path, basename(packagePath)),
  overwrite = TRUE)

rsimPath <- "/Users/daniel/Documents/work/projects/TreatmentStrategiesModel/rpackages/"
file.copy(
  from = packagePath,
  to = stringr::str_c(rsimPath, basename(packagePath)),
  overwrite = TRUE)

## Data
phenotype_table <- fromJSON("/Users/daniel/polybox/Shared/Robot-Shared/treatmentstrategies/experiments/templates/phenotypes.json")
devtools::use_data(phenotype_table, overwrite = TRUE)

std_sim_parameter <- fromJSON("/Users/daniel/Documents/work/projects/TreatmentStrategiesModel/data/20170619_output/antoinemodel/parameter.json")
devtools::use_data(std_sim_parameter, overwrite = TRUE)


theme_bw_custom <- theme_bw() +
      theme(
        # overall text size
        text = element_text(size = 7),
        # legend
        legend.position = "bottom",
        legend.key = element_rect(color = NA),
        # facet labels
        strip.background = element_rect(fill = NA, color = NA),
        strip.text.x = element_text(size = 12, hjust = 0),
        # panel
        panel.border = element_rect(color = NA),
        panel.grid.major = element_line(size = 0.2),
        panel.grid.minor = element_blank(),
        # axis
        axis.line.x  = element_line(color = "black", size = 0.25),
        axis.line.y  = element_line(color = "black", size = 0.25),
        axis.title.x = element_text(margin = margin(10, 0, 0, 0)),
        axis.title.y = element_text(margin = margin(0, 10, 0, 0))
      )

devtools::use_data(theme_bw_custom, overwrite = TRUE)
